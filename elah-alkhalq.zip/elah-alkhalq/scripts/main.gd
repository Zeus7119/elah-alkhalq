extends Node2D
## إله الخلق — لعبة إله مطلق: اخلق النجوم والكواكب والثقوب السوداء والحياة،
## وحارب آلهةً آخرين في حروب عوالم يليها نزال آلهة. الفائز يمتصّ قوة المهزوم ويحوز عوالمه.

const AI_GOD_NAMES = ["إله الظلام", "إله العاصفة", "إله الجحيم"]
const TOOLS = ["star", "planet", "blackhole", "solarsystem", "galaxy",
	"human", "plant", "animal", "fish", "water", "earth", "mountain"]

signal strike_done

var player: Deity
var gods: Array = []
var bodies_root: Node2D
var camera: Camera2D
var selected_tool := "star"
var war_active := false

# واجهة
var hud_power: Label
var hud_strength: Label
var hud_worlds: Label
var tool_label: Label
var log_box: RichTextLabel
var battle_panel: Control
var battle_title: Label
var battle_log: RichTextLabel
var duel_box: VBoxContainer
var duel_track: ColorRect
var duel_zone: ColorRect
var duel_marker: ColorRect
var strike_btn: Button
var war_popup: PopupMenu
var war_targets: Array = []

# نزال الآلهة
var duel_active := false
var pending_strike := false
var marker_t := 0.0
var marker_dir := 1.0
var wb_player_bonus := 0.0

var bg_points: Array = []

func _ready() -> void:
	setup_theme()
	bodies_root = Node2D.new()
	bodies_root.name = "Worlds"
	add_child(bodies_root)
	camera = Camera2D.new()
	add_child(camera)
	camera.make_current()
	camera.zoom = Vector2(0.8, 0.8)
	make_starfield()
	setup_gods()
	build_ui()
	start_timers()
	update_hud()
	add_log("مرحباً أيها الإله المطلق! مواردك غير محدودة ♾️ — اخلق ما تشاء بلا حدود.")
	add_log("اختر عنصراً من لوحة الخلق ثم انقر في الفضاء. عجلة الفأرة للتقريب، واسحب بالزر الأيمن للتجوّل بين العوالم.")

func setup_theme() -> void:
	var font: Font
	if ResourceLoader.exists("res://assets/fonts/NotoSansArabic-Regular.ttf"):
		font = load("res://assets/fonts/NotoSansArabic-Regular.ttf")
	else:
		var sf := SystemFont.new()
		sf.font_names = ["Noto Sans Arabic", "Noto Naskh Arabic", "Noto Kufi Arabic", "Amiri", "sans-serif"]
		font = sf
	var theme := Theme.new()
	theme.default_font = font
	theme.default_font_size = 20
	get_tree().root.theme = theme

func make_starfield() -> void:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	for i in range(400):
		bg_points.append(Vector2(rng.randf_range(-4000, 4000), rng.randf_range(-4000, 4000)))

func _draw() -> void:
	for p in bg_points:
		draw_circle(p, 1.4, Color(1, 1, 1, 0.55))

# ---------- الآلهة والعوالم ----------

func setup_gods() -> void:
	player = Deity.new("إله الخلق (أنت)", true)
	player.power = 500.0
	player.strength = 1.5
	gods.append(player)
	var positions = [Vector2(1500, -500), Vector2(-1500, 700), Vector2(400, 1600)]
	for i in range(3):
		var g := Deity.new(AI_GOD_NAMES[i], false)
		g.power = randf_range(300, 500)
		g.strength = randf_range(1.0, 2.2)
		gods.append(g)
		build_ai_world(g, positions[i])
	build_player_home()

func build_player_home() -> void:
	var s := spawn_body("star", Vector2.ZERO, player)
	for i in range(2):
		var pl := spawn_body("planet", Vector2.ZERO, player)
		pl.orbit_parent = s
		pl.orbit_radius = 90 + i * 60
		pl.orbit_speed = 0.5 - i * 0.18
		pl.orbit_angle = randf() * TAU
		pl.color = Color.from_hsv(randf(), 0.55, 0.9)
	for i in range(3):
		spawn_body(["human", "plant", "animal"][i], Vector2(randf_range(-200, 200), randf_range(-200, 200)), player)

func build_ai_world(g: Deity, c: Vector2) -> void:
	var s := spawn_body("star", c, g)
	for i in range(2):
		var pl := spawn_body("planet", Vector2.ZERO, g)
		pl.orbit_parent = s
		pl.orbit_radius = 85 + i * 55
		pl.orbit_speed = 0.45 - i * 0.15
		pl.orbit_angle = randf() * TAU
		pl.color = Color.from_hsv(randf(), 0.55, 0.85)
	var life_types = ["human", "plant", "animal", "fish"]
	for i in range(3):
		spawn_body(life_types[randi() % life_types.size()], c + Vector2(randf_range(-180, 180), randf_range(-180, 180)), g)
	spawn_body("water", c + Vector2(randf_range(-220, 220), randf_range(-220, 220)), g)
	spawn_body("earth", c + Vector2(randf_range(-220, 220), randf_range(-220, 220)), g)

func spawn_body(t: String, pos: Vector2, god: Deity) -> CosmicBody:
	var b := CosmicBody.new()
	bodies_root.add_child(b)
	b.setup(t, pos, god)
	god.worlds.append(b)
	return b

# ---------- الإدخال والكاميرا ----------

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			camera.zoom = (camera.zoom * 1.12).clamp(Vector2(0.25, 0.25), Vector2(3.0, 3.0))
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			camera.zoom = (camera.zoom / 1.12).clamp(Vector2(0.25, 0.25), Vector2(3.0, 3.0))
		elif event.button_index == MOUSE_BUTTON_LEFT and event.pressed and not war_active:
			place_tool(get_global_mouse_position())
	elif event is InputEventMouseMotion:
		if event.button_mask & MOUSE_BUTTON_MASK_MIDDLE or event.button_mask & MOUSE_BUTTON_MASK_RIGHT:
			camera.position -= event.relative / camera.zoom.x

func _process(delta: float) -> void:
	var move := Vector2.ZERO
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		move.y -= 1
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		move.y += 1
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		move.x -= 1
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		move.x += 1
	if move != Vector2.ZERO:
		camera.position += move.normalized() * 700.0 * delta / camera.zoom.x
	if duel_active:
		marker_t += marker_dir * delta * 1.35
		if marker_t >= 1.0:
			marker_t = 1.0
			marker_dir = -1.0
		elif marker_t <= 0.0:
			marker_t = 0.0
			marker_dir = 1.0
		duel_marker.position.x = 8 + marker_t * (duel_track.size.x - 10)

# ---------- الخلق (موارد غير محدودة) ----------

func place_tool(pos: Vector2) -> void:
	match selected_tool:
		"solarsystem":
			var s := spawn_body("star", pos, player)
			for i in range(3):
				var pl := spawn_body("planet", Vector2.ZERO, player)
				pl.orbit_parent = s
				pl.orbit_radius = 75 + i * 48
				pl.orbit_speed = 0.55 - i * 0.14
				pl.orbit_angle = randf() * TAU
				pl.color = Color.from_hsv(randf(), 0.6, 0.9)
		_:
			spawn_body(selected_tool, pos, player)
	add_log("✨ خلقتَ: " + CosmicBody.TYPE_INFO[selected_tool]["name"] + " — لا حدود لقدرتك!")
	update_hud()

func _on_tool_selected(t: String) -> void:
	selected_tool = t
	tool_label.text = "أداة الخلق الحالية: " + CosmicBody.TYPE_INFO[t]["name"]

# ---------- المؤقّتات: نمو الحياة وخلق الآلهة وحروبهم ----------

func start_timers() -> void:
	var t1 := Timer.new()
	t1.wait_time = 5.0
	t1.autostart = true
	t1.timeout.connect(_on_growth_tick)
	add_child(t1)
	var t2 := Timer.new()
	t2.wait_time = 35.0
	t2.autostart = true
	t2.timeout.connect(_on_ai_war_tick)
	add_child(t2)

func _on_growth_tick() -> void:
	for g in gods:
		if not g.alive:
			continue
		for w in g.worlds:
			if is_instance_valid(w) and w.is_life:
				w.population += randi_range(1, 4)
		if not g.is_player and randf() < 0.35 and g.worlds.size() < 45:
			var types = ["planet", "star", "water", "earth", "mountain", "human", "animal", "plant", "fish"]
			var c := Vector2.ZERO
			if g.worlds.size() > 0 and is_instance_valid(g.worlds[0]):
				c = g.worlds[0].position
			spawn_body(types[randi() % types.size()], c + Vector2(randf_range(-280, 280), randf_range(-280, 280)), g)
	update_hud()

func _on_ai_war_tick() -> void:
	if war_active or randf() < 0.45:
		return
	var alive_ai: Array = gods.filter(func(g): return g.alive and not g.is_player)
	if alive_ai.size() < 2:
		return
	var a: Deity = alive_ai[randi() % alive_ai.size()]
	var b: Deity = alive_ai[randi() % alive_ai.size()]
	if a == b:
		return
	var pa: float = a.world_power() * a.strength * randf_range(0.8, 1.25)
	var pb: float = b.world_power() * b.strength * randf_range(0.8, 1.25)
	var winner: Deity = a if pa > pb else b
	var loser: Deity = b if winner == a else a
	absorb(winner, loser)
	add_log("⚔️ حرب آلهة: %s هزم %s واحتاز عوالمه وأصبحت قوته طاقةً للفائز!" % [winner.god_name, loser.god_name])
	if gods.filter(func(g): return g.alive and not g.is_player).is_empty():
		add_log("👑 أنت الآن الإله الأوحد في الوجود! كل العوالم لك.")

## الفائز يمتصّ قوة المهزوم ويحوز عوالمه — مصير المهزوم أن يصبح قوة للفائز
func absorb(winner: Deity, loser: Deity) -> void:
	winner.power += loser.power * 0.6
	winner.strength += 0.8
	for w in loser.worlds.duplicate():
		if is_instance_valid(w):
			w.owner_god = winner
			winner.worlds.append(w)
	loser.worlds.clear()
	if not loser.is_player:
		loser.alive = false

# ---------- حرب العوالم (اللاعب) ----------

func _on_war_button() -> void:
	if war_active:
		return
	war_popup.clear()
	war_targets.clear()
	var idx := 0
	for g in gods:
		if not g.is_player and g.alive:
			war_targets.append(g)
			war_popup.add_item("⚔️ %s   (القوة: %d — العوالم: %d)" % [g.god_name, int(g.power), g.living_worlds()], idx)
			idx += 1
	if idx == 0:
		add_log("لا يوجد آلهة أحياء — أنتَ الإله الأوحد في هذا الوجود!")
		return
	war_popup.popup()

func _on_war_target_selected(id: int) -> void:
	if id >= 0 and id < war_targets.size():
		start_war(war_targets[id])

func start_war(defender: Deity) -> void:
	war_active = true
	battle_panel.visible = true
	battle_log.clear()
	duel_box.visible = false
	battle_title.text = "⚔️ حرب العوالم: أنتَ ضدّ " + defender.god_name
	add_log("🔥 أعلنتَ حرب عوالم على " + defender.god_name + "!")
	await run_world_battle(defender)
	duel_box.visible = true
	var player_won_duel: bool = await run_god_duel(defender)
	finish_war(defender, player_won_duel)

## المرحلة الأولى: مخلوقات العالَمين تقاتل
func run_world_battle(defender: Deity) -> void:
	var a_army: float = player.world_power() + player.power * 0.3
	var d_army: float = defender.world_power() + defender.power * 0.3
	var a_rounds := 0
	for i in range(4):
		await get_tree().create_timer(1.1).timeout
		var ar: float = a_army * randf_range(0.7, 1.3)
		var dr: float = d_army * randf_range(0.7, 1.3)
		if ar >= dr:
			a_rounds += 1
			battle_log.append_text("🗡️ الجولة %d: مخلوقات عالمك تتقدّم وتسحق الجحافل!\n" % (i + 1))
		else:
			battle_log.append_text("🛡️ الجولة %d: قوات %s تصدّت لهجومك ببسالة!\n" % [i + 1, defender.god_name])
	await get_tree().create_timer(0.8).timeout
	if a_rounds >= 3:
		wb_player_bonus = 0.12
		battle_log.append_text("🏆 فزتَ بمعركة العوالم! جنودك يهتفون باسمك قبل نزال الآلهة!\n")
	else:
		wb_player_bonus = -0.10
		battle_log.append_text("💀 خسرتَ معركة العوالم... لكن النزال الحقيقي بين الآلهة يبدأ الآن!\n")

## المرحلة الثانية: نزال الآلهة — اضغط عندما يكون المؤشر في المنطقة الخضراء
func run_god_duel(defender: Deity) -> bool:
	battle_title.text = "👑 نزال الآلهة: أنتَ ضدّ " + defender.god_name
	battle_log.append_text("\nاضغط «⚡ اضرب الآن» عندما يكون المؤشر في المنطقة الخضراء! (أفضل من 3 جولات)\n")
	duel_active = true
	var ps := 0
	var ds := 0
	for i in range(3):
		marker_t = 0.0
		marker_dir = 1.0
		pending_strike = true
		await strike_done
		var hit := abs(marker_t - 0.5) <= 0.14
		var chance: float = clamp(player.strength / (player.strength + defender.strength) + 0.2 + wb_player_bonus, 0.1, 0.95)
		if hit and randf() < chance:
			ps += 1
			battle_log.append_text("⚡ ضربة موجعة! تفوّقتَ على %s في الجولة %d!\n" % [defender.god_name, i + 1])
		elif hit:
			ds += 1
			battle_log.append_text("🌑 صدَّ %s ضربتك بقوته المظلمة! (الجولة %d)\n" % [defender.god_name, i + 1])
		else:
			ds += 1
			battle_log.append_text("❌ أخطأتَ التوقيت... استغلّ %s الفرصة! (الجولة %d)\n" % [defender.god_name, i + 1])
	duel_active = false
	return ps >= 2

func _on_strike() -> void:
	if duel_active and pending_strike:
		pending_strike = false
		strike_done.emit()

func finish_war(defender: Deity, player_won: bool) -> void:
	var msg := ""
	if player_won:
		var gained: int = int(defender.power * 0.6)
		absorb(player, defender)
		player.strength += 0.5
		msg = "🏆 انتصرتَ! احتزتَ عوالم %s، وأصبحت قوّته ومصيره طاقةً تغذي قوّتك (+%d)!" % [defender.god_name, gained]
		add_log("👑 هزمتَ " + defender.god_name + " — عوالمه لك الآن وقوته تغذيك!")
	else:
		var lost: float = player.power * 0.5
		defender.power += lost
		defender.strength += 0.6
		var half: int = int(ceil(player.worlds.size() / 2.0))
		var transferred := 0
		while transferred < half and player.worlds.size() > 1:
			var w: CosmicBody = player.worlds[randi() % player.worlds.size()]
			player.worlds.erase(w)
			defender.worlds.append(w)
			w.owner_god = defender
			transferred += 1
		player.power = max(50.0, player.power - lost)
		msg = "💀 هُزمتَ أمام %s... احتاز نصف عوالمك وامتصّ جزءاً من قوّتك. لكن إرادة الخلق لا تنكسر — اخلق من جديد وتعالَ للانتقام!" % defender.god_name
		add_log("💀 هزمك " + defender.god_name + "... عُد أقوى وخذ بثأرك!")
	update_hud()
	await get_tree().create_timer(1.2).timeout
	battle_panel.visible = false
	war_active = false
	var dlg := AcceptDialog.new()
	dlg.title = "⚔️ نتيجة حرب العوالم"
	dlg.dialog_text = msg
	dlg.ok_button_text = "متابعة"
	add_child(dlg)
	dlg.popup_centered()

# ---------- الواجهة ----------

func build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)

	# شريط المعلومات أعلى اليسار
	var hud := VBoxContainer.new()
	hud.set_anchors_preset(Control.PRESET_TOP_LEFT)
	hud.position = Vector2(16, 12)
	hud.add_theme_constant_override("separation", 4)
	layer.add_child(hud)
	var title := Label.new()
	title.text = "🌌 إله الخلق"
	title.add_theme_font_size_override("font_size", 30)
	hud.add_child(title)
	var sub := Label.new()
	sub.text = "مواردك: غير محدودة ♾️"
	sub.add_theme_font_size_override("font_size", 16)
	sub.modulate = Color(1, 1, 0.6)
	hud.add_child(sub)
	hud_power = Label.new()
	hud.add_child(hud_power)
	hud_strength = Label.new()
	hud.add_child(hud_strength)
	hud_worlds = Label.new()
	hud.add_child(hud_worlds)

	# لوحة الخلق على اليمين
	var panel := PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
	panel.offset_left = -280
	panel.offset_top = -330
	panel.offset_bottom = 330
	panel.offset_right = -10
	var pstyle := StyleBoxFlat.new()
	pstyle.bg_color = Color(0.05, 0.05, 0.13, 0.88)
	pstyle.corner_radius = 12
	panel.add_theme_stylebox_override("panel", pstyle)
	layer.add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	panel.add_child(box)
	var ptitle := Label.new()
	ptitle.text = "✨ لوحة الخلق المطلق"
	ptitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ptitle.add_theme_font_size_override("font_size", 24)
	box.add_child(ptitle)
	tool_label = Label.new()
	tool_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tool_label.add_theme_font_size_override("font_size", 15)
	box.add_child(tool_label)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 380)
	box.add_child(scroll)
	var tools_box := VBoxContainer.new()
	tools_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(tools_box)
	for t in TOOLS:
		var btn := Button.new()
		btn.text = "✦ " + CosmicBody.TYPE_INFO[t]["name"]
		btn.pressed.connect(_on_tool_selected.bind(t))
		tools_box.add_child(btn)
	var war_btn := Button.new()
	war_btn.text = "⚔️ إعلان حرب عالمية"
	war_btn.add_theme_font_size_override("font_size", 22)
	war_btn.modulate = Color(1.0, 0.75, 0.75)
	war_btn.pressed.connect(_on_war_button)
	box.add_child(war_btn)
	war_popup = PopupMenu.new()
	layer.add_child(war_popup)
	war_popup.id_pressed.connect(_on_war_target_selected)
	_on_tool_selected("star")

	# سجل الأحداث أسفل اليسار
	var log_panel := PanelContainer.new()
	log_panel.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	log_panel.offset_left = 12
	log_panel.offset_top = -210
	log_panel.offset_bottom = -12
	log_panel.offset_right = 470
	var lstyle := StyleBoxFlat.new()
	lstyle.bg_color = Color(0.05, 0.05, 0.13, 0.8)
	lstyle.corner_radius = 10
	log_panel.add_theme_stylebox_override("panel", lstyle)
	layer.add_child(log_panel)
	log_box = RichTextLabel.new()
	log_box.custom_minimum_size = Vector2(450, 190)
	log_box.bbcode_enabled = true
	log_box.scroll_following = true
	log_box.fit_content = false
	log_box.add_theme_font_size_override("normal_font_size", 15)
	log_panel.add_child(log_box)

	# غطاء المعركة
	battle_panel = Control.new()
	battle_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	battle_panel.visible = false
	layer.add_child(battle_panel)
	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0, 0, 0.72)
	battle_panel.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	battle_panel.add_child(center)
	var bpanel := PanelContainer.new()
	var bstyle := StyleBoxFlat.new()
	bstyle.bg_color = Color(0.09, 0.07, 0.18, 0.98)
	bstyle.corner_radius = 16
	bpanel.add_theme_stylebox_override("panel", bstyle)
	center.add_child(bpanel)
	var bbox := VBoxContainer.new()
	bbox.custom_minimum_size = Vector2(560, 420)
	bbox.add_theme_constant_override("separation", 8)
	bpanel.add_child(bbox)
	battle_title = Label.new()
	battle_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	battle_title.add_theme_font_size_override("font_size", 26)
	bbox.add_child(battle_title)
	battle_log = RichTextLabel.new()
	battle_log.custom_minimum_size = Vector2(540, 200)
	battle_log.bbcode_enabled = true
	battle_log.scroll_following = true
	bbox.add_child(battle_log)
	duel_box = VBoxContainer.new()
	duel_box.visible = false
	duel_box.add_theme_constant_override("separation", 8)
	bbox.add_child(duel_box)
	var duel_area := Control.new()
	duel_area.custom_minimum_size = Vector2(540, 44)
	duel_box.add_child(duel_area)
	duel_track = ColorRect.new()
	duel_track.color = Color(0.2, 0.2, 0.3)
	duel_track.position = Vector2(8, 14)
	duel_track.size = Vector2(524, 16)
	duel_area.add_child(duel_track)
	duel_zone = ColorRect.new()
	duel_zone.color = Color(0.2, 0.9, 0.4, 0.55)
	duel_zone.position = Vector2(8 + 524 * 0.36, 14)
	duel_zone.size = Vector2(524 * 0.28, 16)
	duel_area.add_child(duel_zone)
	duel_marker = ColorRect.new()
	duel_marker.color = Color(1, 0.3, 0.3)
	duel_marker.position = Vector2(8, 8)
	duel_marker.size = Vector2(10, 28)
	duel_area.add_child(duel_marker)
	strike_btn = Button.new()
	strike_btn.text = "⚡ اضرب الآن!"
	strike_btn.add_theme_font_size_override("font_size", 26)
	strike_btn.pressed.connect(_on_strike)
	duel_box.add_child(strike_btn)

func update_hud() -> void:
	hud_power.text = "⚡ قوّتك: %d" % int(player.power)
	hud_strength.text = "💪 شدّتك: %.1f" % player.strength
	hud_worlds.text = "🪐 عوالمك: %d" % player.living_worlds()

func add_log(text: String) -> void:
	log_box.append_text(text + "\n")
